// yazı renk değişme

let lblsilver = document.querySelector('#color1');
let lblgold = document.querySelector('#color2');

lblsilver.addEventListener('click', () => btnPrimary.style.backgroundColor = '#a6a6a6')
lblgold.addEventListener('click', () => btnDanger.style.backgroundColor = '#957d41')
// yazı renk değişme